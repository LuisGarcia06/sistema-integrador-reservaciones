(function () {
  const App = window.App = window.App || {};
  const DEFAULT_ROUTE = "dashboard";
  const LOGIN_ROUTE = "login";
  const PUBLIC_ROUTES = [LOGIN_ROUTE];
  let renderId = 0;
  let renderedPage = null;

  function getRouteFromHash() {
    const hash = window.location.hash || "";
    const route = hash.replace(/^#\//, "").trim();
    return route || DEFAULT_ROUTE;
  }

  function renderUnknown(routeId) {
    App.layout.setShellMode("authenticated");
    App.layout.updateActiveNavigation("");
    App.layout.setPageHeader({
      title: "Ruta no encontrada",
      subtitle: "La sección solicitada no existe en esta base visual"
    });

    document.getElementById("page-root").innerHTML = [
      '<section class="page">',
      App.ui.placeholder(
        "No se encontró la vista",
        'La ruta "#/' + App.ui.escapeHtml(routeId) + '" no está registrada. Usa la navegación principal para volver a una sección disponible.'
      ),
      '<a class="btn btn-primary" href="#/dashboard">Volver a Dashboard</a>',
      "</section>"
    ].join("");
  }

  function renderUnauthorized() {
    App.layout.setShellMode("authenticated");
    App.layout.updateActiveNavigation("");
    App.layout.setPageHeader({
      title: "Acceso no autorizado",
      subtitle: "Tu usuario no tiene permisos para esta sección"
    });

    document.getElementById("page-root").innerHTML = [
      '<section class="page">',
      App.ui.emptyState(
        "Acceso no autorizado",
        "Tu alcance de visualización no permite abrir esta sección."
      ),
      '<a class="btn btn-primary" href="#/dashboard">Volver a Dashboard</a>',
      "</section>"
    ].join("");
  }

  function isPublicRoute(routeId) {
    return PUBLIC_ROUTES.includes(routeId);
  }

  async function renderRoute() {
    const activeRenderId = ++renderId;
    const routeId = getRouteFromHash();
    const page = App.pages && App.pages[routeId];
    const pageRoot = document.getElementById("page-root");
    const isAuthenticated = App.auth && App.auth.estaAutenticado();
    if (App.unified?.active && renderedPage && !PUBLIC_ROUTES.includes(renderedPage) && isAuthenticated && pageRoot.childElementCount && !App.unified.canLeave(renderedPage)) {
      if (routeId !== renderedPage) history.replaceState(null, "", "#/" + renderedPage);
      return;
    }

    if (routeId === LOGIN_ROUTE && isAuthenticated) {
      navigate(DEFAULT_ROUTE);
      return;
    }

    if (!isPublicRoute(routeId) && !isAuthenticated) {
      navigate(LOGIN_ROUTE);
      return;
    }

    if (isAuthenticated && !isPublicRoute(routeId)) {
      try { await App.auth.refrescarSesion(); } catch (error) { return; }
      if (activeRenderId !== renderId || routeId !== getRouteFromHash()) return;
    }

    if (!page) {
      if(App.unified?.active&&renderedPage)App.pages[renderedPage]?.resetSession?.();
      renderedPage=routeId;
      renderUnknown(routeId);
      return;
    }

    if (!isPublicRoute(routeId) && (!App.auth.puedeAccederPagina(routeId) || (page.adminOnly && !App.auth.esAdministrador()))) {
      if(App.unified?.active&&renderedPage)App.pages[renderedPage]?.resetSession?.();
      renderedPage=routeId;
      renderUnauthorized();
      pageRoot.focus({ preventScroll: true });
      return;
    }

    if (isPublicRoute(routeId)) {
      App.layout.setShellMode("guest");
    } else {
      App.layout.setShellMode("authenticated");
      App.layout.updateActiveNavigation(routeId);
      App.layout.setPageHeader({
        title: page.title,
        subtitle: page.subtitle
      });
    }

    if (App.unified?.active && renderedPage) App.pages[renderedPage]?.resetSession?.();
    pageRoot.innerHTML = page.render();
    renderedPage = routeId;
    if (App.unified?.active) App.unified.preparePage(pageRoot);

    if (typeof page.afterRender === "function") {
      page.afterRender();
    }

    if (App.notificaciones) App.notificaciones.onRouteRendered(routeId);

    pageRoot.focus({ preventScroll: true });
  }

  function navigate(routeId) {
    const nextHash = "#/" + routeId;

    if (window.location.hash === nextHash) {
      renderRoute();
      return;
    }

    window.location.hash = nextHash;
  }

  function init() {
    window.addEventListener("hashchange", renderRoute);
    window.addEventListener("permisosactualizados", renderRoute);

    if (!window.location.hash) {
      navigate(DEFAULT_ROUTE);
      return;
    }

    renderRoute();
  }

  App.router = {
    init: init,
    navigate: navigate,
    renderRoute: renderRoute
  };
})();
