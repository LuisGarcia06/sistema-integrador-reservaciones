const bcrypt = require('bcryptjs');
const pool = require('../config/database');
const auditoria = require('./bitacora.service');
const { ROLES } = require('../constants/roles');
const { validarDatosActualizacionUsuario } = require('../validators/usuarios.validator');

const BCRYPT_SALT_ROUNDS = 12;
const credenciales = require('../security/credentialPolicy');
const correo023 = async (db, correo) => {
    const entrada=credenciales.email(correo);
    const clave=(await db.query('SELECT public.ctsk_correo_clave_023($1) clave',[entrada])).rows[0].clave;
    if(entrada.toLowerCase()!==clave)credenciales.fail(409,'EMAIL_NORMALIZATION_REVIEW_REQUIRED');
    return clave;
};
const validarRol023 = rol => {
    if(credenciales.active()&&!['Administrador','Consulta'].includes(rol?.nombre))credenciales.fail(400,'ROL_NO_SOPORTADO');
};
const marcarFallo023 = error => {
    if(credenciales.active()&&/^[A-Z0-9]{5}$/.test(error.code||'')&&!['23503','23505'].includes(error.code))error.escrituraUsuarioFallida=true;
};
const MENSAJE_AUTO_DESACTIVACION = 'No puedes desactivar tu propia cuenta de Administrador.';
const MENSAJE_AUTO_DEGRADACION = 'No puedes cambiar tu propio rol de Administrador.';
const MENSAJE_ULTIMO_ADMIN = 'No se puede desactivar o cambiar el rol del último Administrador activo.';

const camposActualizables = [
    'nombre',
    'correo',
    'id_rol',
    'estado',
    'alcance_plataformas'
];

const columnasUsuarioPublico = `
    u.id_usuario,
    u.nombre,
    u.correo,
    u.id_rol,
    r.nombre AS rol,
    u.estado,
    u.alcance_plataformas,
    ARRAY(
        SELECT upv.id_plataforma
        FROM usuario_plataformas_visibles upv
        WHERE upv.id_usuario = u.id_usuario
        ORDER BY upv.id_plataforma
    ) AS platform_ids
`;

const obtenerUsuarios = async () => {
    const query = `
        SELECT
            ${columnasUsuarioPublico}
        FROM usuarios u
        INNER JOIN roles r
            ON r.id_rol = u.id_rol
        ORDER BY
            u.estado DESC,
            u.nombre ASC,
            u.id_usuario ASC
    `;

    const result = await pool.query(query);

    return result.rows;
};

const obtenerRoles = async () => {
    const query = `
        SELECT
            id_rol,
            nombre
        FROM roles
        ORDER BY
            nombre ASC,
            id_rol ASC
    `;

    const result = await pool.query(query);

    return result.rows;
};

const obtenerRolPorIdConDb = async (db, idRol) => {
    const query = `
        SELECT
            id_rol,
            nombre
        FROM roles
        WHERE id_rol = $1
        LIMIT 1
    `;

    const result = await db.query(query, [idRol]);

    return result.rows[0];
};

const obtenerUsuarioPorIdConDb = async (db, idUsuario, bloquear = false) => {
    const query = `
        SELECT
            ${columnasUsuarioPublico}
        FROM usuarios u
        INNER JOIN roles r
            ON r.id_rol = u.id_rol
        WHERE u.id_usuario = $1
        LIMIT 1
        ${bloquear ? 'FOR UPDATE OF u' : ''}
    `;

    const result = await db.query(query, [idUsuario]);

    return result.rows[0];
};

const obtenerUsuarioPorId = async (idUsuario) => obtenerUsuarioPorIdConDb(pool, idUsuario);

const hashearPassword = (password) => bcrypt.hash(password, BCRYPT_SALT_ROUNDS);

const crearErrorReglaNegocio = (mensaje) => {
    const error = new Error(mensaje);
    error.statusCode = 409;
    return error;
};

const tieneCampo = (objeto, campo) => Object.prototype.hasOwnProperty.call(objeto, campo);

const esAdministradorActivo = (usuario) => (
    Boolean(usuario) &&
    usuario.estado === true &&
    usuario.rol === ROLES.ADMINISTRADOR
);

const esMismoUsuario = (idUsuario, usuarioAutenticado) => (
    Boolean(usuarioAutenticado) &&
    Number(idUsuario) === Number(usuarioAutenticado.id_usuario)
);

const obtenerAdministradoresActivosConBloqueo = async (db) => {
    const query = `
        SELECT
            u.id_usuario
        FROM usuarios u
        INNER JOIN roles r
            ON r.id_rol = u.id_rol
        WHERE r.nombre = $1
          AND u.estado = true
        ORDER BY
            u.id_usuario ASC
        FOR UPDATE OF u
    `;

    const result = await db.query(query, [ROLES.ADMINISTRADOR]);

    return result.rows;
};

const construirEstadoFinalUsuario = (usuarioActual, campos, rolActualizado) => {
    const rolFinal = tieneCampo(campos, 'id_rol')
        ? rolActualizado.nombre
        : usuarioActual.rol;
    const estadoFinal = tieneCampo(campos, 'estado')
        ? campos.estado
        : usuarioActual.estado;

    return {
        rol: rolFinal,
        estado: estadoFinal
    };
};

const validarProteccionAdministradores = (
    idUsuario,
    usuarioActual,
    campos,
    usuarioAutenticado,
    rolActualizado,
    administradoresActivos
) => {
    const estadoFinal = construirEstadoFinalUsuario(usuarioActual, campos, rolActualizado);
    const eraAdministradorActivo = esAdministradorActivo(usuarioActual);
    const sigueAdministradorActivo = (
        estadoFinal.estado === true &&
        estadoFinal.rol === ROLES.ADMINISTRADOR
    );
    const reduceAdministradoresActivos = eraAdministradorActivo && !sigueAdministradorActivo;

    if (esMismoUsuario(idUsuario, usuarioAutenticado) && usuarioActual.rol === ROLES.ADMINISTRADOR) {
        if (tieneCampo(campos, 'estado') && campos.estado === false) {
            throw crearErrorReglaNegocio(MENSAJE_AUTO_DESACTIVACION);
        }

        if (tieneCampo(campos, 'id_rol') && estadoFinal.rol !== ROLES.ADMINISTRADOR) {
            throw crearErrorReglaNegocio(MENSAJE_AUTO_DEGRADACION);
        }
    }

    if (!reduceAdministradoresActivos) {
        return;
    }

    if (administradoresActivos.length <= 1) {
        throw crearErrorReglaNegocio(MENSAJE_ULTIMO_ADMIN);
    }
};

const crearErrorAlcance = (mensaje) => {
    const error = new Error(mensaje);
    error.statusCode = 400;
    return error;
};

const prepararAlcanceUsuario = async (db, campos, rolFinal, usuarioActual = null) => {
    const tieneModo = tieneCampo(campos, 'alcance_plataformas');
    const tieneIds = tieneCampo(campos, 'platform_ids');
    const esConsulta = rolFinal === ROLES.CONSULTA;

    if (!esConsulta) {
        if (tieneModo || tieneIds) {
            throw crearErrorAlcance('El alcance solo se configura para usuarios Consulta');
        }
        return null;
    }

    if ((!usuarioActual || usuarioActual.rol === ROLES.ADMINISTRADOR) && !tieneModo) {
        throw crearErrorAlcance('Debe definir explícitamente el alcance final del usuario Consulta');
    }

    if (!tieneModo && !tieneIds) {
        return null;
    }

    const configuracion = {};
    if (tieneModo) configuracion.alcance_plataformas = campos.alcance_plataformas;
    if (tieneIds) configuracion.platform_ids = campos.platform_ids;
    const validacion = validarDatosActualizacionUsuario(configuracion);
    if (validacion.errores.length) throw crearErrorAlcance(validacion.errores.join('. '));

    const modo = tieneModo ? campos.alcance_plataformas : usuarioActual.alcance_plataformas;
    const ids = tieneIds ? validacion.camposActualizacion.platform_ids
        : auditoria.usuariosActivos() && modo === 'selected' && usuarioActual?.alcance_plataformas === 'selected'
            ? usuarioActual.platform_ids : [];
    if (!['all', 'selected'].includes(modo)) throw crearErrorAlcance('Alcance inválido');
    if (modo === 'all' && ids.length) throw crearErrorAlcance('all no admite asignaciones seleccionadas');

    if (ids.length) {
        const result = await db.query(
            'SELECT id_plataforma FROM plataformas WHERE id_plataforma = ANY($1::int[]) ORDER BY id_plataforma FOR KEY SHARE',
            [ids]
        );
        if (result.rows.length !== ids.length) throw crearErrorAlcance('Una o más plataformas no existen');
    }
    return { alcance_plataformas: modo, platform_ids: ids };
};

const guardarPlataformasUsuario = async (db, idUsuario, ids) => {
    await db.query('DELETE FROM usuario_plataformas_visibles WHERE id_usuario = $1', [idUsuario]);
    if (ids.length) {
        await db.query(
            'INSERT INTO usuario_plataformas_visibles (id_usuario, id_plataforma) SELECT $1, unnest($2::int[])',
            [idUsuario, ids]
        );
    }
};

const crearUsuario = async (usuario) => {
    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        const rol = await obtenerRolPorIdConDb(client, usuario.id_rol);
        validarRol023(rol);

        if (!rol) {
            const error = new Error('Rol no encontrado');
            error.statusCode = 400;
            throw error;
        }

        const alcance = await prepararAlcanceUsuario(client, usuario, rol.nombre);
        if(credenciales.active()){
            credenciales.password(usuario.password);
            usuario={...usuario,correo:await correo023(client,usuario.correo)};
        }
        const passwordHash = await hashearPassword(usuario.password);
        const query = `
            INSERT INTO usuarios (
                id_rol,
                nombre,
                correo,
                password,
                estado,
                alcance_plataformas
            )
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING
                id_usuario
        `;
        const result = await client.query(query, [
            usuario.id_rol,
            usuario.nombre,
            usuario.correo,
            passwordHash,
            usuario.estado,
            alcance ? alcance.alcance_plataformas : 'all'
        ]);

        if (alcance) await guardarPlataformasUsuario(client, result.rows[0].id_usuario, alcance.platform_ids);
        const usuarioCreado = await obtenerUsuarioPorIdConDb(client, result.rows[0].id_usuario);
        if(credenciales.active())await auditoria.registrarAuditoriaEstructurada({recurso:'usuarios',anterior:null,nuevo:usuarioCreado},client);

        await client.query('COMMIT');

        return usuarioCreado;
    } catch (error) {
        await client.query('ROLLBACK');
        marcarFallo023(error);
        throw error;
    } finally {
        client.release();
    }
};

const obtenerCambiosUsuario = (usuarioActual, campos) => (
    Object.keys(campos).filter((campo) => usuarioActual[campo] !== campos[campo])
);

const actualizarUsuarioConDb = async (db, idUsuario, campos) => {
    const nombresCampos = Object.keys(campos);
    const asignaciones = nombresCampos.map((campo, index) => {
        if (!camposActualizables.includes(campo)) {
            throw new Error('Campo de actualización no permitido');
        }

        return `${campo} = $${index + 1}`;
    });

    const values = nombresCampos.map((campo) => campos[campo]);
    values.push(idUsuario);

    const query = `
        UPDATE usuarios
        SET
            ${asignaciones.join(',\n            ')}
        WHERE id_usuario = $${values.length}
        RETURNING
            id_usuario
    `;

    const result = await db.query(query, values);

    return result.rows[0];
};

const actualizarUsuarioParcial = async (idUsuario, campos, usuarioAutenticado) => {
    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        const requiereProteccionAdministradores = tieneCampo(campos, 'estado') || tieneCampo(campos, 'id_rol');
        let usuarioActual = await obtenerUsuarioPorIdConDb(client, idUsuario, !requiereProteccionAdministradores);

        if (!usuarioActual) {
            await client.query('COMMIT');
            return null;
        }

        let rolActualizado = null;

        if (Object.prototype.hasOwnProperty.call(campos, 'id_rol')) {
            rolActualizado = await obtenerRolPorIdConDb(client, campos.id_rol);
            validarRol023(rolActualizado);

            if (!rolActualizado) {
                const error = new Error('Rol no encontrado');
                error.statusCode = 400;
                throw error;
            }
        }

        if (
            requiereProteccionAdministradores &&
            esMismoUsuario(idUsuario, usuarioAutenticado) &&
            usuarioActual.rol === ROLES.ADMINISTRADOR
        ) {
            const estadoFinal = construirEstadoFinalUsuario(usuarioActual, campos, rolActualizado);

            if (tieneCampo(campos, 'estado') && campos.estado === false) {
                throw crearErrorReglaNegocio(MENSAJE_AUTO_DESACTIVACION);
            }

            if (tieneCampo(campos, 'id_rol') && estadoFinal.rol !== ROLES.ADMINISTRADOR) {
                throw crearErrorReglaNegocio(MENSAJE_AUTO_DEGRADACION);
            }
        }

        if (requiereProteccionAdministradores) {
            const administradoresActivos = await obtenerAdministradoresActivosConBloqueo(client);
            usuarioActual = await obtenerUsuarioPorIdConDb(client, idUsuario, true);

            if (!usuarioActual) {
                await client.query('COMMIT');
                return null;
            }

            validarProteccionAdministradores(
                idUsuario,
                usuarioActual,
                campos,
                usuarioAutenticado,
                rolActualizado,
                administradoresActivos
            );
        }

        const rolFinal = construirEstadoFinalUsuario(usuarioActual, campos, rolActualizado).rol;
        if(credenciales.active()&&!['Administrador','Consulta'].includes(rolFinal))credenciales.fail(400,'ROL_NO_SOPORTADO');
        if(credenciales.active()&&tieneCampo(campos,'correo'))campos={...campos,correo:await correo023(client,campos.correo)};
        const alcance = await prepararAlcanceUsuario(client, campos, rolFinal, usuarioActual);
        const camposGuardables = Object.fromEntries(Object.entries(campos).filter(([campo]) => camposActualizables.includes(campo)));
        if (alcance) camposGuardables.alcance_plataformas = alcance.alcance_plataformas;
        const camposConCambios = obtenerCambiosUsuario(usuarioActual, camposGuardables);

        const auditoriaUsuario = auditoria.usuariosActivos();
        const cambianAsignaciones = Boolean(alcance) && (!auditoriaUsuario
            || JSON.stringify(usuarioActual.platform_ids) !== JSON.stringify(alcance.platform_ids));

        if (camposConCambios.length === 0 && (auditoriaUsuario ? !cambianAsignaciones : !alcance)) {
            await client.query('COMMIT');
            return usuarioActual;
        }

        const camposActualizados = {};

        camposConCambios.forEach((campo) => {
            camposActualizados[campo] = camposGuardables[campo];
        });

        if (auditoriaUsuario) {
            auditoria.exigirMotivo(client);
            const propuesta = {...usuarioActual,...camposActualizados,
                platform_ids: alcance ? alcance.platform_ids : usuarioActual.platform_ids};
            const compatibilidad = await client.query(`SELECT
                public.ctsk_admin_snapshot_valido_022('usuarios',$1::jsonb) anterior,
                public.ctsk_admin_snapshot_valido_022('usuarios',$2::jsonb) nuevo`, [
                JSON.stringify(auditoria.fotoAuditoria('usuarios',usuarioActual)),
                JSON.stringify(auditoria.fotoAuditoria('usuarios',propuesta))
            ]);
            if (compatibilidad.rows[0]?.anterior !== true || compatibilidad.rows[0]?.nuevo !== true) {
                const error = crearErrorReglaNegocio('El estado público del usuario no es compatible con la auditoría 022. Requiere revisión sin normalización automática.');
                error.code = 'USUARIO_AUDITORIA_INCOMPATIBLE';
                throw error;
            }
        }

        if (camposConCambios.length) await actualizarUsuarioConDb(client, idUsuario, camposActualizados);
        if (cambianAsignaciones) await guardarPlataformasUsuario(client, idUsuario, alcance.platform_ids);

        const usuarioActualizado = await obtenerUsuarioPorIdConDb(client, idUsuario);

        if (auditoriaUsuario) await auditoria.registrarAuditoriaEstructurada({recurso:'usuarios',anterior:usuarioActual,nuevo:usuarioActualizado}, client);

        await client.query('COMMIT');

        return usuarioActualizado;
    } catch (error) {
        await client.query('ROLLBACK');
        // En el contrato nuevo un fallo SQL inesperado de escritura es tecnico:
        // no convertirlo en un rechazo durable solo por pertenecer a clase 22.
        // Unicidad y FK conservan las respuestas comerciales existentes.
        if (auditoria.usuariosActivos() && /^[A-Z0-9]{5}$/.test(error.code || '')
            && !['23503','23505'].includes(error.code)) error.escrituraUsuarioFallida = true;
        throw error;
    } finally {
        client.release();
    }
};

const actualizarPasswordUsuario = async (idUsuario, password) => {
    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        const usuarioActual = await obtenerUsuarioPorIdConDb(client, idUsuario, true);

        if (!usuarioActual) {
            await client.query('COMMIT');
            return null;
        }

        if(credenciales.active()){auditoria.exigirMotivo(client);credenciales.password(password);}
        const passwordHash = await hashearPassword(password);
        const query = `
            UPDATE usuarios
            SET
                password = $1
            WHERE id_usuario = $2
            RETURNING
                id_usuario
        `;

        await client.query(query, [passwordHash, idUsuario]);

        const usuarioActualizado = await obtenerUsuarioPorIdConDb(client, idUsuario);

        if(credenciales.active())await auditoria.registrarCambioPassword(idUsuario,client);

        await client.query('COMMIT');

        return usuarioActualizado;
    } catch (error) {
        await client.query('ROLLBACK');
        marcarFallo023(error);
        throw error;
    } finally {
        client.release();
    }
};

module.exports = {
    BCRYPT_SALT_ROUNDS,
    obtenerUsuarios,
    obtenerRoles,
    obtenerUsuarioPorId,
    crearUsuario,
    actualizarUsuarioParcial,
    actualizarPasswordUsuario
};
